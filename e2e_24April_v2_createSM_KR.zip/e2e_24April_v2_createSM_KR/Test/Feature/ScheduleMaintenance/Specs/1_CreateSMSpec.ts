import { browser, element, ExpectedConditions, $, by,protractor } from "protractor";
import { LoginPage } from "../../Login/PO/loginPO";
import { MainScheduledMaintenancePO } from "../PO/MainScheduledMaintenancePO";
import { ScheduledMaintenanceIndexPO } from "../PO/ScheduledMaintenanceIndexPO";
import { SMTopPanePO } from "../PO/ScheduleMaintenanceTopPanePO";
import * as prop from "../../../../TestData/prop.json";

describe("Scheduled Maintenance", function () {
  let loginPage = new LoginPage();
  let SM = new MainScheduledMaintenancePO();
  let SMIndex = new ScheduledMaintenanceIndexPO();
  let SMTopPane = new SMTopPanePO();
  let originalTimeout: any;
  
 

  beforeAll(async function () {
    browser.waitForAngularEnabled(false);
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
  })
  afterEach(function () {
    browser.sleep(1000);
  })
  afterAll(function () {
    console.log(">>>>>Test for Creating new scheduled maintenance done<<<<<\n");
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  })

  it("Launch url check", async function () {
    await loginPage.getPage();
    let title = await loginPage.getTitle();
    expect(title).toEqual('Fiix');
  })
  it("Login as user", async function () {
    let loginUserNameElem = await loginPage.setUserName();
    await loginUserNameElem.sendKeys((<any>prop).Tenant1.username);
    let loginUserNameElemCheckValue = await loginUserNameElem.getAttribute('value');
    expect(loginUserNameElemCheckValue).toContain((<any>prop).Tenant1.username);

    let loginPasswordElem = await loginPage.setPassword();
    await loginPasswordElem.sendKeys((<any>prop).Tenant1.password);
    let loginPasswordElemCheckValue = await loginPasswordElem.getAttribute('value');
    expect(loginPasswordElemCheckValue).toContain((<any>prop).Tenant1.password);

    let signinButtonElement = await loginPage.clickLoginButton();
    await signinButtonElement.click();

    let dashboardIconElem = await loginPage.confirmLogin();
    let dashboardIconText = await dashboardIconElem.getText();
    expect(dashboardIconText).toContain("Dashboard");
  })
  it("Create new scheduled maintenance", async function () {
    await SMIndex.selectSite();
    let smCode = await SM.createAndReturnSMCode();
    await SMTopPane.clickBack2();
    let smCodeConfirm = await  SMIndex.searchForSM(smCode);
    expect(smCodeConfirm).toContain(smCode);

  })
  it("Logoff as user", async function () {
    let logOffButtonElem = await loginPage.clickLogOffButton();
    await logOffButtonElem.click();

    let button = await loginPage.getSignInButtonPresence();
    let buttonVisibility = await button.isDisplayed();
    expect(buttonVisibility).toBe(true);
  })
})
