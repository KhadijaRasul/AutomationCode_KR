import { browser,$, ExpectedConditions } from "protractor";
import { CommonLocators } from "../../../Lib/CommonLocators";
import { SMLocators } from "../Locators/SMLocators";


export class SMTopPanePO {
    smLocators = new SMLocators();
    commonLocators = new CommonLocators();

    //being used:
    public getSMCode() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('.saveButtonAct.action')), 5000)
            .then(() => browser.driver.findElement(this.smLocators.getCode()))
            .then((smCodeElement)=> smCodeElement.getAttribute("value"));
        //let smCode = await browser.findElement(this.smLocators.getCode()).getAttribute("value");
        //return smCode;
    }
    //being used:
    public clickSave() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('.saveButtonAct.action')), 5000)
            .then(() => browser.driver.findElement(this.smLocators.clickSaveButton2()))
            .then((result)=> result.click());
       // browser.findElement(this.smLocators.clickSaveButton()).click();
    }
    
     //being used:
    public clickBack2(){
        
        var until1 = ExpectedConditions;
        
        return browser.driver.wait(until1.elementToBeClickable($('.saveButtonAct.action')), 10000)
        .then(()=> browser.driver.wait(until1.presenceOf($('.formNoticeSuccess')), 10000))
        .then(()=>browser.driver.wait(until1.stalenessOf($('.formNoticeSuccess')), 10000))
        .then(()=> browser.driver.findElement(this.smLocators.clickBackButton()))
        .then((result)=> result.click())
    }

}