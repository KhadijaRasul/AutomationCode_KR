
import { SMTopPanePO } from "./ScheduleMaintenanceTopPanePO";

export class MainScheduledMaintenancePO {
   
    SMTopPane = new SMTopPanePO();

    public async createAndReturnSMCode() {
        let smCode = await this.SMTopPane.getSMCode();
        await this.SMTopPane.clickSave();
        return smCode;
    }
}
