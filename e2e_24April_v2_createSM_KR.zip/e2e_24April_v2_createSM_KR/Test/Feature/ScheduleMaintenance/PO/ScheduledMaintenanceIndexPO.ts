import { browser, by, $, ExpectedConditions, element, protractor } from "protractor";
import { CommonLocators } from "../../../Lib/CommonLocators";
import { SMLocators } from "../Locators/SMLocators";


export class ScheduledMaintenanceIndexPO {
    smLocators = new SMLocators();
    commonLocators = new CommonLocators();
    
    //being used:
    public clickOnMaintenance() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('#logoffBtnBottom')), 5000)
            .then(() => browser.driver.findElement(this.smLocators.getMaintenanceIcon2()))
            .then((maintenanceLinkElem)=> maintenanceLinkElem.click())
        
    }
    //being used:
    public scheduledMaintenanceIndexPage() {

        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('#logoffBtnBottom')), 5000)
            .then(()=> browser.driver.wait(until1.textToBePresentInElement($('span.listTopLabelLarge'),'Work Orders'), 5000))
            .then(() => element(by.xpath('//*[@class="pk-active"]/ul[@class="pk-subnavigation"]/li[contains(text(),"Scheduled Maintenance")]')).isPresent())
            .then(() => browser.driver.findElement(this.smLocators.clickScheduledMaintenanceSM()))
            .then((result) => result.click());
        
    }
    //being used:
    public createButtonPresence() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('.create')), 10000)
            .then(() => browser.driver.findElement(this.smLocators.getCreateButton2()))
            .then((result) => result.click());
    }
    //being used:
    public createButtonPresence2() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.visibilityOf($('.create')), 1000)
            .then(() => browser.driver.findElement(this.smLocators.getCreateButton2()))
            .catch((err) => console.log("create button element not found cause " + err));
    }

    //being used:
    public clickNewButton() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('#contextButtonNew')), 5000)
            .then(() => browser.driver.findElement(this.smLocators.clickNewButton2()))
            .then((newButtonElem) => newButtonElem.click());
    }
    //being used:
    public async sitePickerWindowPresence() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.presenceOf($('.modalWindowFrame.ui-draggable')), 10000)
            .then(() => browser.driver.findElement(this.smLocators.clickSiteName()))
    }
    //being used:
    public async sitePickerWindowPresence2() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.presenceOf($('.modalWindowFrame.ui-draggable')), 10000)
            .then(() => browser.driver.findElement(this.smLocators.clickSiteName()))
            .catch((err) => console.log("site picker element not found cause " + err));
    }
    
    public getSite() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.visibilityOf($('.ui-draggable-handle')), 5000)
            .then(() => browser.driver.findElement(this.smLocators.clickSiteName()))
            .then((siteNameElem) => siteNameElem.click());
    }
    //being used:
    public async selectSite() {

        await this.clickOnMaintenance();
        await this.scheduledMaintenanceIndexPage();
        

        if (await this.createButtonPresence2()) {
            await this.createButtonPresence();
        }
        else {
            await this.clickNewButton();
        }

        if (await this.sitePickerWindowPresence2()) {
            await this.getSite();
        }

    }
     
    //being used:
    public async searchForSM(smCode: any) {
        let until1 = ExpectedConditions;
        //new kr code
        let x;
        return browser.driver.wait(until1.elementToBeClickable($('#contextButtonNew')), 10000)
            .then(() => browser.driver.wait(until1.visibilityOf($('.listSearchLarge')), 10000))
            .then(() => browser.driver.wait(until1.elementToBeClickable($('input[id*=_search____searchtermparameter]')), 10000))
            .then(() => browser.driver.findElement(this.smLocators.searchSMImdex()))
            .then((result) => result.sendKeys(smCode))
            .then(() => browser.driver.findElement(this.smLocators.getSearchIconSMIndex()))
            .then((result2) => result2.click())
            .then(() => browser.driver.wait(until1.textToBePresentInElement($('.listPagingContainer35 div span'), '1 record.'), 10000))
            .then(() => browser.driver.findElement(by.xpath('//tbody[contains(@id,"_tbodyx")]/tr[1]//p[contains(text(),"SM")]')))
            .then((result3) => result3.getText());
}

}
