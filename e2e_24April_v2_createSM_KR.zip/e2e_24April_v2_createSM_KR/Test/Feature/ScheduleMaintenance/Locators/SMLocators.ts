import { by, $ } from "protractor";



export class SMLocators {

    //Following are locators for SM Index page:

    public getMaintenanceIcon2() {
        return by.className('pk-icon-maintenance');
    }
    public clickScheduledMaintenanceSM() {
        return by.xpath('//*[@class="pk-active"]/ul[@class="pk-subnavigation"]/li[contains(text(),"Scheduled Maintenance")]');
    }
    public clickNewButton() {
        return $('#contextButtonNew');
    }
    public clickNewButton2() {
        return by.id('contextButtonNew');
    }
    public async getSitePickerWindow() {
        return $('.modalWindowFrame.ui-draggable');
    }
    public async getSitePickerWindow2() {
        return by.className('modalWindowFrame ui-draggable');
    }
    public clickSiteName() {
        return by.xpath('//*[@id="SitesAndRegions_tableContainer"]//p[contains(text(),"(No Site)")]');
    }
    public searchSMImdex() {
        return by.xpath('(//*[@class="listSearchLarge"])//input');
    }
    public getSearchIconSMIndex() {
        return by.xpath('(//*[@class="listSearchLarge"])[1]/div');
    }
    public getCodeFromSMIndex() {
        return by.xpath('//div[@class="listPagingContainer35"]/div/span');

    }
    public getCreateButton() {
        return $('.create');
    }
    public getCreateButton2() {
        return by.className('create');
    }

    public clickSaveButton2() {
        return by.className("saveButtonAct action");
    }
    public clickBackButton() {
        return by.xpath('//span[contains(@id,"_1228_hd")]/div/div[1]');
    }
    //Following are locators for General Tab of SM Edit page:

    public getCode() {
        return by.xpath('(//div[contains(@id,"_column_strCode_cell")]//div[@class="formCellInside35"])//input[@type="text"]');
    }
}
