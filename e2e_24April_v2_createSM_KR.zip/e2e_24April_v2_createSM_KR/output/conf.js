"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = {
    framework: "jasmine",
    capabilities: {
        browserName: 'chrome',
        shardTestFiles: false
    },
    specs: ['Test/Feature/ScheduleMaintenance/Specs/1_CreateSMSpec.js'],
    //specs: ['Test/Feature/Login/Specs/loginSpec.js'],
    seleniumAddress: 'http://localhost:4444/wd/hub'
};
