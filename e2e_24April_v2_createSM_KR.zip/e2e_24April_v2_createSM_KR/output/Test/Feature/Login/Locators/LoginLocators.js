"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var protractor_1 = require("protractor");
var LoginLocators = /** @class */ (function () {
    function LoginLocators() {
    }
    LoginLocators.prototype.getDashboardIcon = function () {
        return protractor_1.by.xpath('//div[@class="pk-icon-dashboard"]/span[contains(text(),"Dashboard")]');
    };
    return LoginLocators;
}());
exports.LoginLocators = LoginLocators;
