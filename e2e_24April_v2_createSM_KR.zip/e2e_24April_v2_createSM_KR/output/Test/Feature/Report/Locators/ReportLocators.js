"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var protractor_1 = require("protractor");
var prop = __importStar(require("../../../../TestData/prop.json"));
var ReportLocators = /** @class */ (function () {
    function ReportLocators() {
    }
    ReportLocators.prototype.getReportIcon = function () {
        return protractor_1.by.className('pk-icon-reports');
    };
    ReportLocators.prototype.getReportIndexPage = function () {
        return protractor_1.by.xpath('//*[@class="pk-active"]/ul[@class="pk-subnavigation"]/li[contains(text(),"Reports")]');
    };
    ReportLocators.prototype.getReportFilterDropDown = function () {
        //console.log("lalalal");
        return protractor_1.by.xpath('//div[contains(@id,"_filter_btn")]');
    };
    ReportLocators.prototype.getReportFilter = function () {
        //console.log("lalalal");
        return protractor_1.by.xpath('//div[@class="modalWindowFrame ui-draggable"]/span[contains(@id,"_bd")]//div[@class="contentPaneFrameModal"]//div[@class="listLargeMain"]//div[contains(@id,"_bd")]//tbody[contains(@id,"_tbodyx")]//p[contains(text(),"' + prop.Tenant1.reportCategoryName + '")]');
    };
    ReportLocators.prototype.getReport = function () {
        console.log("apr 15");
        return protractor_1.by.xpath('//div[contains(@id,"__contentFrame")]//div[contains(@id,"_bd")]//div[@id="Reports_tableContainer"]//tbody[contains(@id,"_tbodyx")]//p[contains(text(),"' + prop.Tenant1.reportName + '")]');
    };
    ReportLocators.prototype.getRunReportButton = function () {
        console.log("apr 15");
        return protractor_1.by.xpath('//div[contains(@id,"__contentFrame")]//div[contains(@id,"_bd")]//div[@id="Reports_tableContainer"]//tbody[contains(@id,"_tbodyx")]//p[contains(text(),"' + prop.Tenant1.reportName + '")]');
    };
    ReportLocators.prototype.getRunButton = function () {
        return protractor_1.by.id('contextButtonRun');
    };
    ReportLocators.prototype.getReportFromDate = function () {
        //console.log("lalalal");
        return protractor_1.by.xpath('//div[@class="modalWindowFrame ui-draggable"]//span[contains(@id,"_bd")]//div[@id="_var_p_1_dateTrigger"]');
    };
    ReportLocators.prototype.getReportToDate = function () {
        //console.log("lalalal");
        return protractor_1.by.xpath('//div[@class="modalWindowFrame ui-draggable"]//span[contains(@id,"_bd")]//div[@class="contentPaneFrameModal"]//div[@id="_var_p_2_dateTrigger"]');
    };
    return ReportLocators;
}());
exports.ReportLocators = ReportLocators;
