"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var protractor_1 = require("protractor");
var CommonLocators_1 = require("../../../Lib/CommonLocators");
//import { LoginLocators} from "../Locators/ReportLocators";
var ReportLocators_1 = require("../Locators/ReportLocators");
var ReportIndexPO = /** @class */ (function () {
    function ReportIndexPO() {
        this.commonLocators = new CommonLocators_1.CommonLocators();
        this.rptLocators = new ReportLocators_1.ReportLocators();
    }
    ReportIndexPO.prototype.clickOnReport = function () {
        protractor_1.browser.findElement(this.rptLocators.getReportIcon()).click();
    };
    ReportIndexPO.prototype.clickReportIndexPage = function () {
        protractor_1.browser.findElement(this.rptLocators.getReportIndexPage()).click();
        console.log("weeee");
    };
    ReportIndexPO.prototype.clickReportFilterDropDown = function () {
        protractor_1.browser.findElement(this.rptLocators.getReportFilterDropDown()).click();
    };
    ReportIndexPO.prototype.clickReportFilter = function () {
        protractor_1.browser.findElement(this.rptLocators.getReportFilter()).click();
        console.log("shalalal");
    };
    ReportIndexPO.prototype.clickReport = function () {
        protractor_1.browser.findElement(this.rptLocators.getReport()).click();
        console.log("clicked on report");
    };
    ReportIndexPO.prototype.FindReport = function () {
        protractor_1.browser.driver.sleep(1000);
        this.clickOnReport();
        protractor_1.browser.driver.sleep(2000);
        this.clickReportIndexPage();
        protractor_1.browser.sleep(2000);
        this.clickReportFilterDropDown();
        protractor_1.browser.sleep(2000);
        this.clickReportFilter();
        protractor_1.browser.sleep(5000);
        this.clickReport();
        protractor_1.browser.sleep(5000);
    };
    return ReportIndexPO;
}());
exports.ReportIndexPO = ReportIndexPO;
