"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var protractor_1 = require("protractor");
var CommonLocators_1 = require("../../../Lib/CommonLocators");
//import { LoginLocators} from "../Locators/ReportLocators";
var ReportLocators_1 = require("../Locators/ReportLocators");
var ReportIndexPO_1 = require("./ReportIndexPO");
var ReportDetailPO_1 = require("./ReportDetailPO");
var MainReportPage = /** @class */ (function () {
    function MainReportPage() {
        this.commonLocators = new CommonLocators_1.CommonLocators();
        this.rptLocators = new ReportLocators_1.ReportLocators();
        this.ReportIndex = new ReportIndexPO_1.ReportIndexPO();
        this.ReportDetail = new ReportDetailPO_1.ReportDetailPO();
    }
    MainReportPage.prototype.runReport = function () {
        protractor_1.browser.driver.sleep(1000);
        this.ReportIndex.FindReport();
        console.log("inside main report..about to complete test");
        protractor_1.browser.sleep(2000);
        this.ReportDetail.RunReport();
        protractor_1.browser.sleep(2000);
    };
    return MainReportPage;
}());
exports.MainReportPage = MainReportPage;
