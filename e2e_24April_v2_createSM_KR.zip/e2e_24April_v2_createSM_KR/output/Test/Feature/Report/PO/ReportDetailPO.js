"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var protractor_1 = require("protractor");
var CommonLocators_1 = require("../../../Lib/CommonLocators");
//import { LoginLocators} from "../Locators/ReportLocators";
var ReportLocators_1 = require("../Locators/ReportLocators");
var ReportDetailPO = /** @class */ (function () {
    function ReportDetailPO() {
        this.commonLocators = new CommonLocators_1.CommonLocators();
        this.rptLocators = new ReportLocators_1.ReportLocators();
    }
    ReportDetailPO.prototype.clickOnRunButton = function () {
        protractor_1.browser.findElement(this.rptLocators.getRunButton()).click();
    };
    ReportDetailPO.prototype.clickFromDate = function () {
        protractor_1.browser.findElement(this.rptLocators.getReportFromDate()).click();
        console.log("weeee");
    };
    ReportDetailPO.prototype.clickToDate = function () {
        protractor_1.browser.findElement(this.rptLocators.getReportToDate()).click();
        console.log("weeee");
    };
    /*public clickReportFilterDropDown(){
        browser.findElement(this.rptLocators.getReportFilterDropDown()).click();
    }
    public clickReportFilter(){
        browser.findElement(this.rptLocators.getReportFilter()).click();
        console.log("shalalal");
    }
    public clickReport(){
        browser.findElement(this.rptLocators.getReport()).click();
        console.log("clicked on report");
    }*/
    ReportDetailPO.prototype.RunReport = function () {
        protractor_1.browser.driver.sleep(1000);
        this.clickOnRunButton();
        protractor_1.browser.driver.sleep(2000);
        this.clickFromDate();
        protractor_1.browser.driver.sleep(2000);
        /*this.selectFromDatePicker();
        browser.sleep(2000);
        this.selectToDatePicker();
        browser.sleep(2000);
        
        this.clickReportFilterDropDown();
        browser.sleep(2000);
        
        this.clickReportFilter();
        browser.sleep(5000);
        
        this.clickReport();
        browser.sleep(5000);*/
    };
    return ReportDetailPO;
}());
exports.ReportDetailPO = ReportDetailPO;
