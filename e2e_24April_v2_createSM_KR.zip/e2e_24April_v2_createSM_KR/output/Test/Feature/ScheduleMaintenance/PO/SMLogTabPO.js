"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SMLogTabPO = /** @class */ (function () {
    function SMLogTabPO() {
    }
    return SMLogTabPO;
}());
exports.SMLogTabPO = SMLogTabPO;
