"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SMGeneralTabPO = /** @class */ (function () {
    function SMGeneralTabPO() {
    }
    return SMGeneralTabPO;
}());
exports.SMGeneralTabPO = SMGeneralTabPO;
