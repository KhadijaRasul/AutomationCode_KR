"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var protractor_1 = require("protractor");
var CommonLocators_1 = require("../../../Lib/CommonLocators");
var SMLocators_1 = require("../Locators/SMLocators");
var SMTopPanePO = /** @class */ (function () {
    function SMTopPanePO() {
        this.smLocators = new SMLocators_1.SMLocators();
        this.commonLocators = new CommonLocators_1.CommonLocators();
    }
    //being used:
    SMTopPanePO.prototype.getSMCode = function () {
        var _this = this;
        var until1 = protractor_1.ExpectedConditions;
        return protractor_1.browser.driver.wait(until1.elementToBeClickable(protractor_1.$('.saveButtonAct.action')), 5000)
            .then(function () { return protractor_1.browser.driver.findElement(_this.smLocators.getCode()); })
            .then(function (smCodeElement) { return smCodeElement.getAttribute("value"); });
        //let smCode = await browser.findElement(this.smLocators.getCode()).getAttribute("value");
        //return smCode;
    };
    //being used:
    SMTopPanePO.prototype.clickSave = function () {
        var _this = this;
        var until1 = protractor_1.ExpectedConditions;
        return protractor_1.browser.driver.wait(until1.elementToBeClickable(protractor_1.$('.saveButtonAct.action')), 5000)
            .then(function () { return protractor_1.browser.driver.findElement(_this.smLocators.clickSaveButton2()); })
            .then(function (result) { return result.click(); });
        // browser.findElement(this.smLocators.clickSaveButton()).click();
    };
    //being used:
    SMTopPanePO.prototype.clickBack2 = function () {
        var _this = this;
        var until1 = protractor_1.ExpectedConditions;
        return protractor_1.browser.driver.wait(until1.elementToBeClickable(protractor_1.$('.saveButtonAct.action')), 10000)
            .then(function () { return protractor_1.browser.driver.wait(until1.presenceOf(protractor_1.$('.formNoticeSuccess')), 10000); })
            .then(function () { return protractor_1.browser.driver.wait(until1.stalenessOf(protractor_1.$('.formNoticeSuccess')), 10000); })
            .then(function () { return protractor_1.browser.driver.findElement(_this.smLocators.clickBackButton()); })
            .then(function (result) { return result.click(); });
    };
    return SMTopPanePO;
}());
exports.SMTopPanePO = SMTopPanePO;
