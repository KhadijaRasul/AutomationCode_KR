import {Config, browser} from "protractor"

export let config: Config =
{
    framework: "jasmine",
    
    capabilities :
    { 
        browserName: 'chrome',
        shardTestFiles: false
    },


 specs: ['Test/Feature/ScheduleMaintenance/Specs/1_CreateSMSpec.js'],
  //specs: ['Test/Feature/Login/Specs/loginSpec.js'],


    seleniumAddress: 'http://localhost:4444/wd/hub'
}