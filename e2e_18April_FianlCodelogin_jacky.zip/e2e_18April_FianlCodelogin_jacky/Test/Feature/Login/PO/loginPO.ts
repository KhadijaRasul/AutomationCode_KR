import { browser, By, $, ExpectedConditions } from "protractor";
import { CommonLocators } from "../../../Lib/CommonLocators";
import { LoginLocators } from "../Locators/Loginlocators";
import * as prop from "../../../../TestData/prop.json";

export class LoginPage {
    commonLocators = new CommonLocators();
    loginLocators = new LoginLocators();

    public getPage() {
        browser.driver.manage().window().maximize();
        return Promise.resolve(browser.driver.get((<any>prop).Tenant1.url));
    }

    public getTitle() {
        return browser.driver.getTitle();
    }
    public getSignInTextLogin() {
        var until = ExpectedConditions;
        return browser.driver.wait(until.elementToBeClickable($('.loginButton')), 5000)
            .then(() => browser.driver.findElement(this.commonLocators.getTextSignInLogin()));
    }
    public getSignInButtonPresence() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('.loginButton')), 5000)
            .then(() => browser.driver.findElement(this.commonLocators.getLoginButton2()));
    }
    public async getForgotYourPasswordLink() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('.loginButton')), 5000)
            .then(() => browser.driver.findElement(this.commonLocators.getForgotPasswordLinkLogin()));
    }
    public getUserNameField() {
        return browser.driver.findElement(this.commonLocators.getUserNameLogin());
    }
    public getPasswordField() {
        return browser.driver.findElement(this.commonLocators.getPasswordLogin());
    }
    public setUserName() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('.loginButton')), 5000)
            .then(() => browser.driver.findElement(this.commonLocators.getUserNameLogin()));
    }
    public setPassword() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('.loginButton')), 5000)
            .then(() => browser.driver.findElement(this.commonLocators.getPasswordLogin()));
    }
    public clickLoginButton() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('.loginButton')), 5000)
            .then(() => browser.driver.findElement(this.commonLocators.getLoginButton2()));
    }
    public clickLogOffButton() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('#logoffBtnBottom')), 5000)
            .then(() => browser.driver.findElement(this.commonLocators.getLogOFFButton2()));
    }
    public async confirmLogin() {
        var until1 = ExpectedConditions;
        return browser.driver.wait(until1.elementToBeClickable($('#logoffBtnBottom')), 5000)
            .then(() => browser.driver.findElement(this.loginLocators.getDashboardIcon()));
    }
    public confirmLogOff() {
        this.getSignInButtonPresence();
    }
}

